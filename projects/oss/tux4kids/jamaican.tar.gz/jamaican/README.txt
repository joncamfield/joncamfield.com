Select Options -> Setup Language and choose "Jamaican" to load the Jamaica Theme!

TuxType - Jamaica was created by Kyle Haefner and Jon Camfield (GriffJon.com), who served as IT volunteers in Jamaica from 2002-2004.

TuxType is part of the Tux4Kids project -- Learn more at Tux4Kids.com!